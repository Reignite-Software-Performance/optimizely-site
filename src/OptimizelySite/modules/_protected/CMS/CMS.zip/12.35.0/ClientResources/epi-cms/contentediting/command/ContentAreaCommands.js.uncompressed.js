define("epi-cms/contentediting/command/ContentAreaCommands", [
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/Stateful",
    "dojo/when",
    "dijit/Destroyable",

    // epi
    "epi-cms/ApplicationSettings",
    "epi-cms/command/Spliter",
    "epi-cms/plugin-area/content-reference-list-command",
    "./BlockRemove",
    "./BlockEdit",
    "./ContentAreaItemBlockEdit",
    "./BlockInlineEdit",
    "./MoveVisibleToPrevious",
    "./MoveVisibleToNext",
    "./Personalize",
    "./SelectDisplayOption",
    "./MoveOutsideGroup"
], function (
    // dojo
    array,
    declare,
    Stateful,
    when,
    Destroyable,

    // epi
    ApplicationSettings,
    SpliterCommand,
    contentReferenceListCommandPluginArea,
    Remove,
    Edit,
    ContentAreaItemBlockEdit,
    InlineEdit,
    MoveVisibleToPrevious,
    MoveVisibleToNext,
    Personalize,
    SelectDisplayOption,
    MoveOutsideGroup
) {

    return declare([Stateful, Destroyable], {
        // tags:
        //      internal

        commands: null,

        constructor: function () {
            this._commandSpliter = this._commandSpliter || new SpliterCommand();
            this.contentAreaItemBlockEdit = new ContentAreaItemBlockEdit({ category: null });
            this.blockInlineEdit = new InlineEdit();
            this.moveVisibleToPrevious = new MoveVisibleToPrevious();
            this.moveVisibleToNext = new MoveVisibleToNext();
            this.commands = [
                new Edit({ category: null }),
                this.contentAreaItemBlockEdit,
                this.blockInlineEdit,
                this._commandSpliter,
                new SelectDisplayOption(),
                this.moveVisibleToPrevious,
                this.moveVisibleToNext,
                new Remove()
            ];
            var sectionsVisibility = Object.assign({}, ApplicationSettings.sectionsVisibility);
            // Only add personalize command if the ui is not limited
            if (!ApplicationSettings.limitUI && (sectionsVisibility.visitorGroups !== false)) {
                this.moveOutsideGroup = new MoveOutsideGroup();
                this.personalize = new Personalize({ category: null });
                this.commands.splice(4, 0, this.personalize, this.moveOutsideGroup);
            }

            this.commands.forEach(function (command) {
                this.own(command);
            }, this);

            [].concat(contentReferenceListCommandPluginArea.get()).forEach(function (command) {
                if (command.putOnTop) {
                    this.commands.unshift(command);
                } else {
                    this.commands.push(command);
                }
            }, this);
        },

        handleDoubleClick: function (itemModel) {
            if (itemModel.inlineBlockData) {
                when(this.contentAreaItemBlockEdit.updateModel(itemModel)).then(function () {
                    this.contentAreaItemBlockEdit.execute();
                }.bind(this));
            } else {
                when(this.blockInlineEdit.updateModel(itemModel)).then(function () {
                    this.blockInlineEdit.execute();
                }.bind(this));
            }
        },

        _modelSetter: function (model) {
            this.model = model;

            array.forEach(this.commands, function (command) {
                command.set("model", model);
            });
        }
    });
});
