require({cache:{
'url:epi-cms/contentediting/editors/propertyvaluelist/templates/CollapsiblePropertyValueListItem.html':"<div class=\"epi-property-value-list__item collapsible\">\r\n    <div class=\"epi-property-value-list__index\"></div>\r\n    <div class=\"epi-property-value-list__content\">\r\n        <div class=\"header\">\r\n            <div class=\"title\">\r\n                <div class=\"expander\" data-dojo-attach-point=\"expander\">\r\n                    <span class=\"dijitArrowButtonInner dijitRightArrowButton\" data-dojo-attach-point=\"expanderIcon\"></span>\r\n                    <span data-dojo-attach-point=\"headerNode\"></span>\r\n                </div>\r\n            </div>\r\n            <span class=\"dijitIcon epi-iconContextMenu\"></span>\r\n        </div>\r\n        <div class=\"block-data-container hidden\" data-dojo-attach-point=\"containerNode\"></div>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-cms/contentediting/editors/propertyvaluelist/PropertyValueListBlockItem", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom-construct",
    "dojo/on",
    "dojo/aspect",
    // dijit
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/_TemplatedMixin",
    "epi/shell/DestroyableByKey",
    "epi/string",
    "./PropertyValueListBlockEditFormContainer",
    // resources
    "dojo/text!./templates/CollapsiblePropertyValueListItem.html"
], function (
    // dojo
    declare,
    domConstruct,
    on,
    aspect,
    // dijit
    _WidgetBase,
    _Container,
    _TemplatedMixin,
    DestroyableByKey,
    epiString,
    PropertyValueListBlockEditFormContainer,
    // resources
    collapsibleTemplate
) {
    function transformKeysToCamelCase(obj) {
        // summary:
        //      Recursively transforms all object keys from PascalCase to camelCase
        // tags:
        //      private

        if (obj === null || obj === undefined) {
            return obj;
        }

        // Handle arrays
        if (Array.isArray(obj)) {
            return obj.map(function (item) {
                return transformKeysToCamelCase(item);
            });
        }

        // Handle objects
        if (typeof obj === "object") {
            var result = {};
            for (var key in obj) {
                if (Object.prototype.hasOwnProperty.call(obj, key)) {
                    var camelKey = epiString.pascalToCamel(key);
                    result[camelKey] = transformKeysToCamelCase(obj[key]);
                }
            }
            return result;
        }

        // Primitive values
        return obj;
    }

    function getValueOrInitialValue(metadata) {
        if (!metadata || !metadata.properties || !metadata.settings) {
            return {};
        }

        var value = metadata.settings.value;
        var hasValue = value && Object.keys(value).length > 0;
        if (hasValue) {
            return value;
        }

        var data = {};
        metadata.properties.forEach(function (propertyMetadata) {
            if (propertyMetadata.initialValue !== null && propertyMetadata.initialValue !== undefined) {
                var camelCaseName = epiString.pascalToCamel(propertyMetadata.name);
                // Recursively transform nested objects
                data[camelCaseName] = transformKeysToCamelCase(propertyMetadata.initialValue);
            }
        });
        return data;
    }

    return declare([_WidgetBase, _Container, _TemplatedMixin, DestroyableByKey], {
        // summary:
        //      The view for the PropertyValueListBlockItem.
        // tags:
        //      internal

        templateString: collapsibleTemplate,

        // metadata: [readonly] Object
        //      Metadata of the list item
        metadata: null,

        expander: null,
        expanderIcon: null,
        expanded: false,

        buildRendering: function () {
            this.inherited(arguments);
            this.editor = new PropertyValueListBlockEditFormContainer({
                metadata: this.metadata,
                doLayout: false
            });
            domConstruct.place(this.editor.domNode, this.containerNode);
            var editorValue = getValueOrInitialValue(this.metadata);
            this.editor.set("value", editorValue);
            this.headerNode.innerHTML = this.listItemHeaderFormatter(editorValue);
            if (this._started && !this.editor._started) {
                this.editor.startup();
            }

            this.own(aspect.after(this.editor, "onChange", function (value) {
                return Object.assign(value, { contentTypeGuid: this.metadata.settings[this.metadata.settings.contentTypeGuidKeyName] });
            }.bind(this), true));

            this.own(on(this.expander, "click", this.expand.bind(this)));
        },

        getDisplayedValue: function () {
            return "";
        },

        isValid: function () {
            return this.editor.isValid();
        },

        expand: function () {
            this.expanded = !this.expanded;
            this.expanderIcon.classList.toggle("dijitRightArrowButton");
            this.containerNode.classList.toggle("hidden");
            if (this.expanded) {
                this.ownByKey("changedHandler", this.editor.on("change", function (formValue) {
                    this.onStartEdit();
                    this.onChange(formValue);
                    this.onStopEdit();
                    this.headerNode.innerHTML = this.listItemHeaderFormatter(formValue);
                }.bind(this)));
            } else {
                this.destroyByKey("changedHandler");
            }
        },

        onChange: function (value) {
            // summary:
            //      callback method called when the value has changed
            //  tags:
            //      public
        },

        onStartEdit: function () {
            // summary:
            //      callback method called when editor is activated
            //  tags:
            //      public
        },

        onStopEdit: function () {
            // summary:
            //      callback method called when editor is no longer active
            //  tags:
            //      public
        }
    });
});
