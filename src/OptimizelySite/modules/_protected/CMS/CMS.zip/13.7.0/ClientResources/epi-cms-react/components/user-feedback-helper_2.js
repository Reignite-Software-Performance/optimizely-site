define(["require","exports"],(function(r,t){"use strict";const s=e=>new CustomEvent("setUserMessage",{detail:e}),n=e=>{document.dispatchEvent(s(e)),parent!==window&&parent.document.dispatchEvent(s(e))};t.showUserMessage=n}));
//# sourceMappingURL=user-feedback-helper_2.js.map
