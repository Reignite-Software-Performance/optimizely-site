define("epi-cms/ContentContextHandler", [
    "dojo/_base/declare",
    "dijit/Destroyable",
    "dojo/topic",
    "dojo/when",
    "require",
    "epi-cms/_ContentContextMixin"
], function (declare, Destroyable, topic, when, moduleRequire, _ContentContextMixin) {
    return declare([Destroyable, _ContentContextMixin], {
        // summary:
        //      Initializes content context related features.
        // tags:
        //      internal
        _contextEventManager: null,
        _contextKey: "content",
        initialize: function () {
            var _this = this;
            moduleRequire(["epi/shell/dist/contextEventManager"], function (cem) {
                _this._contextEventManager = cem.ContextEventManager;
                var unsubscribe = _this._contextEventManager.onRefresh(_this._contextKey, _this._refreshContent.bind(_this));
                _this.own({
                    destroy: unsubscribe
                });
                // The first context usually arrives before this module has loaded, so publish it now.
                when(_this.getCurrentContext(), function (ctx) {
                    if (this._isContentContext(ctx)) {
                        this._publishContentEvent(ctx);
                    }
                }.bind(_this));
            });
        },
        contentContextChanged: function (ctx) {
            this.inherited(arguments);
            this._publishContentEvent(ctx);
        },
        contentContextUpdated: function (ctx) {
            this.inherited(arguments);
            this._publishContentEvent(ctx);
        },
        _publishContentEvent: function (ctx) {
            // tags:
            //    private
            if (!this._contextEventManager) {
                return; // Not loaded yet; initialize publishes the latest context once it is.
            }
            var payload = {
                key: ctx.key,
                version: "".concat(ctx.version),
                locale: ctx.language,
                previewUrl: ctx.previewUrl,
                displayName: ctx.displayName || ctx.name,
                contentLink: ctx.id
            };
            this._contextEventManager.change(this._contextKey, payload);
        },
        _refreshContent: function () {
            // tags:
            //    private
            topic.publish("/epi/shell/context/refreshcurrent");
        }
    });
});
