/**
 * @file Unified module loader that handles ESM modules (Vite-built)
 *
 * @module epi/esm-loader
 */
define("epi/esm-loader", ["require"], function (moduleRequire) {
    var cachedModules = {};
    function getScriptContent(functionName, url) {
        return "window.".concat(functionName, " = async function() {\n            const module = await import(\"").concat(url, "\");\n            return module;\n        }");
    }
    return {
        /**
         * Loads an ESM module by absolute URL using native dynamic import().
         * Results are cached by URL so each module is only fetched once.
         *
         * If the module has a default export, that export is resolved directly,
         * removing the need for callers to unwrap `.default` themselves.
         *
         * @param {string} url - Absolute URL of the ES module to load.
         * @returns {Promise<*>} Resolves with the module's default export if present,
         *   otherwise resolves with the full module namespace object.
         *   Rejects if the module cannot be loaded.
         */
        loadEsmModule: function (url) {
            if (!cachedModules[url]) {
                cachedModules[url] = new Promise(function (resolve, reject) {
                    var script = document.createElement("script");
                    var functionName = "onLoadEs6" + Date.now() + Math.floor(Math.random() * 10000);
                    function cleanup() {
                        script.remove();
                        delete window[functionName];
                    }
                    script.innerHTML = getScriptContent(functionName, url);
                    document.body.appendChild(script);
                    setTimeout(function () {
                        window[functionName]().then(function (module) {
                            cleanup();
                            resolve(module["default"] !== undefined ? module["default"] : module);
                        }, function (error) {
                            cleanup();
                            delete cachedModules[url];
                            reject(error);
                        });
                    }, 0);
                });
            }
            return cachedModules[url];
        },
        /**
         * Loads an ESM module by AMD module ID, resolving it to a real URL
         * via require.toUrl() using the configured Dojo package paths.
         * The .js extension is appended automatically if omitted.
         *
         * @param {string} moduleId - AMD module ID, e.g. "epi/shell/dist/messagePublisher".
         * @returns {Promise<*>} Resolves with the module's default export if present,
         *   otherwise resolves with the full module namespace object.
         */
        loadEsmModuleByAmdId: function (moduleId) {
            var id = moduleId.endsWith(".js") ? moduleId : moduleId + ".js";
            return this.loadEsmModule(moduleRequire.toUrl(id));
        }
    };
});
