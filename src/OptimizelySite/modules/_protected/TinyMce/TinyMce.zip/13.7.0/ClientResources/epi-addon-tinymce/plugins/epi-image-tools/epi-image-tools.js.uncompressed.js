define("epi-addon-tinymce/plugins/epi-image-tools/epi-image-tools", [
    "dojo/topic",
    "dijit/Tooltip",
    "epi/Url",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-addon-tinymce/tinymce-loader",
    "epi-addon-tinymce/ContentService",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epiimagetools"
], function (topic, Tooltip, Url, ContentActionSupport, tinymce, ContentService, pluginResources) {

    tinymce.PluginManager.add("epi-image-tools", function (editor) {

        var contentService = new ContentService();
        var tooltipWidget = null;

        function addToolbars() {
            editor.ui.registry.addContextToolbar("epi-gotomedia-toolbar",
                {
                    predicate: function (node) {
                        return node.nodeName.toLowerCase() === "img";
                    },
                    position: "node",
                    items: "epi-gotomedia"
                });
        }

        var uri;

        var updateButton = function (button) {
            var selectedElement = editor.selection.getNode();

            //Check if its a standardimage
            if (selectedElement && selectedElement.tagName === "IMG" && editor.dom.getAttrib(selectedElement, "class").indexOf("mceItem") === -1) {
                var url = new Url(selectedElement.src);
                contentService.getContentFromUrl(url.path)
                    .then(function (content) {
                        // Content from a read-only provider, such as the DAM, has no CMS media to go to.
                        if (!ContentActionSupport.hasProviderCapability(content.providerCapabilityMask, ContentActionSupport.providerCapabilities.Edit)) {
                            return null;
                        }

                        uri = content.uri;
                        return contentService.getPathToContent(content);
                    })
                    .then(function (imagePath) {
                        if (imagePath === null) {
                            button.setEnabled(false);
                            return;
                        }

                        // HACK to get dom due to TinyMCE isn't expose api to do that now.
                        // Note: the button was rendered.
                        // See more: https://www.tiny.cloud/docs/tinymce/6/custom-basic-toolbar-button/#using-onsetup
                        // and TinyMCE API feature request equivalent to: https://github.com/tinymce/tinymce/issues/5966
                        var name = "epi-gotomedia";
                        var buttonRef = document.querySelector("button[data-mce-name='" + name + "'");
                        if (buttonRef) {
                            if (tooltipWidget) {
                                tooltipWidget.destroyRecursive();
                            }
                            tooltipWidget = new Tooltip({
                                connectId: buttonRef,
                                position: ["below"],
                                label: imagePath
                            });
                        }
                        button.setEnabled(true);
                    })
                    .otherwise(function () {
                        button.setEnabled(false);
                    });
            }
        };

        // Register buttons
        editor.ui.registry.addButton("epi-gotomedia", {
            text: pluginResources.gotomedia,
            onAction: function () {
                editor.fire("blur");
                if (uri) {
                    topic.publish("/epi/shell/context/request", { uri: uri }, { sender: this });
                }
            },
            onSetup: function (buttonApi) {
                //Set tooltip the first time tinymce starts after browser refresh
                updateButton(buttonApi);

                function nodeChange() {
                    //Update the tooltip
                    updateButton(buttonApi);
                }

                editor.on("NodeChange", nodeChange);

                return function () {
                    if (tooltipWidget) {
                        tooltipWidget.destroyRecursive();
                    }
                    editor.off("NodeChange", nodeChange);
                };
            }
        });

        addToolbars();

        return {
            getMetadata: function () {
                return {
                    name: "Image tools (epi)",
                    url: "https://www.optimizely.com"
                };
            }
        };
    });
});
