define("epi-addon-tinymce/plugins/epi-image-uploader/epi-image-uploader", [
    "require",
    "dojo/topic",
    "epi/dependency",
    "epi/shell/_ContextMixin",
    "epi-cms/ApplicationSettings",
    "epi-cms/core/ContentReference",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.uploadmultiplefiles"
], function (
    moduleRequire,
    topic,
    dependency,
    _ContextMixin,
    ApplicationSettings,
    ContentReference,
    resources
) {
    var inlineImages = "img[src^='blob:'], img[src^='data:']";
    var clipboardImageName = /^image\.\w+$/;   // what browsers call an image pasted as data rather than as a file, as it has no name of its own

    function dataUriToBlob(src) {
        var match = /^data:([^;,]*)[^,]*?(;base64)?,([\s\S]*)$/.exec(src);
        if (!match) {
            return null;
        }

        var data;
        try {
            if (!match[2]) {
                return new Blob([decodeURIComponent(match[3])], { type: match[1] });   // text, which a Blob encodes as UTF-8
            }
            data = atob(match[3]);
        } catch (error) {
            return null;   // malformed, so it's reported as unreadable rather than losing the whole insert
        }
        var bytes = new window.Uint8Array(data.length);   // atob's binary string, one byte per character
        for (var i = 0; i < data.length; i++) {
            bytes[i] = data.charCodeAt(i);
        }
        return new Blob([bytes], { type: match[1] });
    }

    function uniqueFileName(blob) {
        var extension = (blob.type.split("/")[1] || "png").replace("+xml", "");   // image/svg+xml is an .svg
        return "image" + Math.random().toString(36).slice(2, 10) + "." + extension;
    }

    // Images dropped or pasted into the editor arrive as blob or data URIs, which must never be saved.
    // Holds back the insert, uploads them in the upload dialog, then inserts the content with their uploaded urls.
    return function imageUploader(editor, onInsert) {
        var pending = null;

        function toFile(src) {
            var blobInfo = /^blob:/.test(src) ? editor.editorUpload.blobCache.getByUri(src) : null;
            var blob = blobInfo ? blobInfo.blob() : dataUriToBlob(src);
            return blob && (blob.name && !clipboardImageName.test(blob.name) ? blob : new File([blob], uniqueFileName(blob), { type: blob.type }));   // a file keeps its own name
        }

        function notifyFailure() {
            editor.notificationManager.open({ text: resources.uploadform.errormessage, type: "error" });
        }

        function getContentLink() {
            if (editor._contentLink) {   // set when a block is edited inline
                return window.Promise.resolve(editor._contentLink);
            }
            var contextMixin = new _ContextMixin();
            return window.Promise.resolve(contextMixin.getCurrentContext()).then(function (context) {
                contextMixin.destroy();
                return context.id;
            });
        }

        function upload(files) {
            // summary: Uploads the files to the For This Page/Block folder, resolving with the uploaded content keyed by file name.

            if (!files.length) {
                return window.Promise.resolve({});
            }

            var store = dependency.resolve("epi.storeregistry").get("epi.cms.contentdata");
            var contentLink, assetsFolderLink;

            return getContentLink().then(function (link) {
                contentLink = link;
                return store.refresh(link);
            }).then(function (content) {
                assetsFolderLink = content.assetsFolderLink || content.parentLink;   // media can't have a folder of its own, so its images go beside it
                return new window.Promise(function (resolve) {
                    moduleRequire(["epi-cms-react/components/show-upload-dialog"], resolve);
                });
            }).then(function (uploadDialog) {
                // Content without a folder of its own yet reports the Content Assets root.
                var hasFolder = !ContentReference.compareIgnoreVersion(assetsFolderLink, ApplicationSettings.contentAssetsFolder);
                return uploadDialog.showUploadDialog({   // the CMS upload, as the assets pane's uploader uses
                    uploadUrl: ApplicationSettings.cmsModuleBaseUrl + "FileUpload",
                    fileSizeLimit: ApplicationSettings.fileSizeLimit,
                    canHandleDuplicates: true,
                    destinationFolderId: String(hasFolder ? assetsFolderLink : contentLink),
                    createAsLocalAsset: !hasFolder   // the server creates the folder
                }, files);
            }).then(function (results) {
                topic.publish("/epi/cms/upload", assetsFolderLink);   // refreshes the Media pane, adding the folder if this created it
                return window.Promise.all(results.filter(function (result) {
                    return result.contentLink;
                }).map(function (result) {
                    return window.Promise.resolve(store.get(result.contentLink)).then(function (content) {
                        return { fileName: result.fileName, content: content };
                    });
                }));
            }).then(function (uploads) {
                var contentByFileName = {};
                uploads.forEach(function (uploaded) {
                    contentByFileName[uploaded.fileName] = uploaded.content;
                });
                return contentByFileName;
            });
        }

        function flush() {
            var batch = pending;
            pending = null;

            var images = [];
            batch.docs.forEach(function (doc) {
                images.push.apply(images, doc.querySelectorAll(inlineImages));
            });
            var files = images.map(function (img) {
                return toFile(img.getAttribute("src"));
            });

            function updateImages(contentByFileName) {
                images.forEach(function (img, i) {
                    var content = files[i] && contentByFileName[files[i].name];
                    if (content) {
                        img.setAttribute("src", content.editUrl);
                    } else {
                        img.parentNode.removeChild(img);   // failed or cancelled, so the rest still goes in
                    }
                });
            }

            if (files.indexOf(null) !== -1) {   // a blob this editor no longer has, or a data URI that can't be read
                notifyFailure();
            }

            upload(files.filter(Boolean)).then(updateImages, function () {
                notifyFailure();
                updateImages({});
            }).then(function () {
                var html = batch.docs.map(function (doc) {
                    return doc.body.innerHTML;
                }).join("");

                if (editor.removed) {
                    return;
                }

                editor.focus();   // back from the dialog, even when every image was skipped or failed
                editor.selection.setRng(batch.range);
                if (!html) {   // inserting nothing would still delete the selection
                    return;
                }

                onInsert();   // editing stopped when the dialog took the focus
                if (editor.execCommand("mceInsertContent", false, { content: html, paste: batch.paste, merge: batch.merge })) {
                    editor.dispatch("change");
                }
            });
        }

        editor.on("BeforeSetContent", function (args) {
            if (!args.selection) {   // loading the value rather than inserting
                return;
            }

            var doc = new DOMParser().parseFromString(args.content, "text/html");   // inert, so its images don't load
            if (!doc.querySelector(inlineImages)) {
                return;
            }

            args.preventDefault();

            if (!pending) {
                // A live range rather than a bookmark, so it follows the content if editing carries on meanwhile.
                pending = { docs: [], range: editor.selection.getRng().cloneRange(), paste: args.paste, merge: args.merge };
                window.setTimeout(flush);   // TinyMCE inserts each dropped or pasted file separately, in one loop
            }
            pending.docs.push(doc);
        });

        // The image dialog's Upload tab gives the image a blob source, as automatic uploads are off. The dialog saves a new
        // image and a changed one the same way, so its command is held back until the file is uploaded.
        editor.on("BeforeExecCommand", function (args) {
            var data = args.value;
            if (args.command !== "mceUpdateImage" || !data || !/^(blob|data):/.test(data.src)) {
                return;
            }

            args.preventDefault();
            var range = editor.selection.getRng().cloneRange();   // the image the dialog changes, or where it inserts one
            var file = toFile(data.src);
            if (!file) {
                notifyFailure();
                return;
            }

            upload([file]).then(function (contentByFileName) {
                var content = contentByFileName[file.name];
                if (!content || editor.removed) {
                    return;   // cancelled, so the image stays as it was
                }

                editor.focus();
                editor.selection.setRng(range);
                onInsert();   // editing stopped when the dialog took the focus
                editor.execCommand("mceUpdateImage", false, Object.assign({}, data, { src: content.editUrl }));
            }, notifyFailure);
        });

        // For images_upload_handler, which TinyMCE needs before it shows the image dialog's Upload tab. With automatic
        // uploads off that tab inserts a blob, which the handler above uploads, so TinyMCE itself doesn't call this.
        return function uploadBlob(blobInfo) {
            var file = new File([blobInfo.blob()], blobInfo.filename(), { type: blobInfo.blob().type });
            return upload([file]).then(function (contentByFileName) {
                if (!contentByFileName[file.name]) {
                    throw new Error(resources.uploadform.errormessage);
                }
                return contentByFileName[file.name].editUrl;
            });
        };
    };
});
